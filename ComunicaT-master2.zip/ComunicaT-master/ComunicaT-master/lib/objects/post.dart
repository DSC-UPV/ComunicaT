class Post {
  String title;
  String description;

  Post(this.title, this.description);

  String getTitle(){
    return this.title;
  }

  String getDescription(){
    return this.description;
  }
}
